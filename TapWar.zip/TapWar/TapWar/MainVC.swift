//
//  ViewController.swift
//  TapWar
//
//  Created by CTIS Student on 23.06.2020.
//  Copyright © 2020 CTIS. All rights reserved.
//

import UIKit

class MainVC: UIViewController , delegateResult{
    
    func result(controller: GameVC, data: (Int)) {
        controller.performSegue(withIdentifier: "performExit", sender: controller)
        if data > Int(highScoreLabel.text!)! {
            highScoreLabel.text = "\(data)"

        }
    }
    
    @IBOutlet weak var highScoreLabel: UILabel!
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Reading "highscore" value from UserDefaults
        let highScore = UserDefaults.standard.object(forKey: "highscore")
        
        // First type when you will play the game there will be no key by the sname "highscore"
        if highScore == nil {
            highScoreLabel.text = "0"
        }
        
        // If "highscore" exists in UserDefaults
        if let hScore = highScore as? Int {
            highScoreLabel.text = String(hScore)
        }
    }

    @IBAction func unwindToStart(_ sender: UIStoryboardSegue) {
        
        
    }
}

