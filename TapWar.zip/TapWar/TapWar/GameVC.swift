//
//  GameVC.swift
//  TapWar
//
//  Created by CTIS Student on 23.06.2020.
//  Copyright © 2020 CTIS. All rights reserved.
//

import UIKit

protocol delegateResult {
    func result(controller: GameVC, data:(Int))
}


class GameVC: UIViewController {

    @IBOutlet var imageViewCollection: [UIImageView]!
    @IBOutlet weak var liveLabel: UILabel!
    @IBOutlet weak var scoreLabel: UILabel!
    
    var tapRecognizers = [UITapGestureRecognizer]()

    var score = 0
    var counter = 20
    var timer = Timer()
    var hideTimer = Timer()
    var delegate: delegateResult?
    var speed = 1.0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        liveLabel.text = "Lives: ♥️♥️♥️"
        
        
        createTapGestures()

        speed = 1.0
        
        // Timer to show/hide image and make it appear at a different location
        hideTimer = Timer.scheduledTimer(timeInterval: speed, target: self, selector: #selector(GameVC.hideKenny), userInfo: nil, repeats: true)
        
    }
    
    // Function to attach gesture to each UIImageView manually
       func createTapGestures() {
           for x in 0..<imageViewCollection.count {
               tapRecognizers.append(UITapGestureRecognizer())
               tapRecognizers[x].addTarget(self, action: #selector(GameVC.success))
               imageViewCollection[x].addGestureRecognizer(tapRecognizers[x])
               imageViewCollection[x].isUserInteractionEnabled = true
               //mImageViewCollection[x].tag = x
           }
       }

   
    
    // Function for tap gesture
    @objc func fail() {
        
        if liveLabel.text == "Lives: ♥️♥️♥️" {
            liveLabel.text = "Lives: ♥️♥️"
        }
        else if liveLabel.text == "Lives: ♥️♥️" {
            liveLabel.text = "Lives: ♥️"
        }
        else if liveLabel.text == "Lives: ♥️" {
            liveLabel.text = "Lives: -"
            // Alert creation
            let alert = UIAlertController(title: "Game Over", message: "You have no lives left. Your Score is " + "\(score)", preferredStyle: .alert)
            // Creating and adding Exit Button
            let ok = UIAlertAction(title: " Go to Main Menu", style: .default, handler: { (UIAlertAction) in
                
                self.delegate?.result(controller: self ,data:(self.score))
                self.performSegue(withIdentifier: "performExit", sender: self)

            })
            alert.addAction(ok)
            self.present(alert, animated: true, completion: nil)
        }
        
    }
    
    
    
    // Function for tap gesture
    @objc func success() {
       
        // This is what happens when recognizers get called
        score += 1
        scoreLabel.text = "Score: \(score)"
        speed -= 0.1
        // Timer to show/hide image and make it appear at a different location
        hideTimer = Timer.scheduledTimer(timeInterval: speed, target: self, selector: #selector(GameVC.hideKenny), userInfo: nil, repeats: true)
        
        
    }
    
    // Function for hideTimer
    @objc func hideKenny() {
        for x in 0..<imageViewCollection.count {
            imageViewCollection[x].image = nil
            tapRecognizers[x].removeTarget(self, action: #selector(GameVC.success))
            tapRecognizers[x].addTarget(self, action: #selector(GameVC.fail))
            imageViewCollection[x].addGestureRecognizer(tapRecognizers[x])
            imageViewCollection[x].isUserInteractionEnabled = true
        }
        // Create a random number 0-8 to make the imageView visible
        let randomNumber = Int(arc4random_uniform(UInt32(imageViewCollection.count)))
        imageViewCollection[randomNumber].image = UIImage(named: "sponge1")
        imageViewCollection[randomNumber].isUserInteractionEnabled = true
        
        tapRecognizers[randomNumber].removeTarget(self, action: #selector(GameVC.fail))
        
        tapRecognizers[randomNumber].addTarget(self, action: #selector(GameVC.success))
        imageViewCollection[randomNumber].addGestureRecognizer(tapRecognizers[randomNumber])
        imageViewCollection[randomNumber].isUserInteractionEnabled = true
    
    }
}
